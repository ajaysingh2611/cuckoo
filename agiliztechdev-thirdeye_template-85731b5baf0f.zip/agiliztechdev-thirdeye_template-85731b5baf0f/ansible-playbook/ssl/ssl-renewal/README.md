# Script usage

```
bash <Script path>/ssl-renew.sh <domain-name> <no. of days to renew the certificate> <ssl-sert-check path>

```

# Ex:

```
bash /thirdeye/ssl-renew.sh unleash-app.com 10 >> /var/log/ssl-renewal-check.log 2>&1

```
## Cron job entry
# this will run on evry 3rd day

```
0 0 */3 * *  bash <Script path>/ssl-renew.sh  <no. of days to renew the certificate> <ssl-sert-check path> >> /var/log/ssl-renewal-check.log 2>&1
```