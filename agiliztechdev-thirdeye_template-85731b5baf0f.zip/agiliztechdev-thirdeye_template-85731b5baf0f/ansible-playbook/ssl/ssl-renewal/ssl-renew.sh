#!/bin/bash

DOMAIN=$1
COMPARE=$2 
SCRIPTPATH=$3 # ssl-cert-check
DATE=$(date +%Y-%m-%d)
EXPIREDATE=`bash $SCRIPTPATH -p 443 -s $DOMAIN | grep $DOMAIN |awk '{print $6}'`

if [[ $EXPIREDATE -le $COMPARE ]]
then 
   echo "$DATE: Renew the certificate on: $DATE"
   certbot-auto certonly --nginx -d $DOMAIN --register-unsafely-without-email --force-renewal
else
   echo "$DATE: No need to update ssl certificate, Remaining days: $EXPIREDATE" 
fi